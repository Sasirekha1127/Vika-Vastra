// src/components/Dashboard/Dashboard.jsx
import { useEffect, useState, useMemo } from 'react';
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend,
} from 'recharts';

const API = process.env.REACT_APP_API_URL;

function fmtINR(n) {
  if (n == null || n === '-') return '—';
  return '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
}
function fmtNum(n) {
  if (n == null || n === '-') return '—';
  return Number(n).toLocaleString('en-IN');
}
function stockColor(s) {
  if (s === 0)  return '#DC2626';
  if (s <= 50)  return '#E8520A';
  if (s <= 200) return '#C8A200';
  return '#2D7A1F';
}
function stockLabel(s) {
  if (s === 0)  return 'Out of Stock';
  if (s <= 50)  return 'Low Stock';
  if (s <= 200) return 'Medium';
  return 'In Stock';
}
function growthColor(v) {
  return v > 0 ? '#2D7A1F' : v < 0 ? '#DC2626' : '#6B7280';
}

const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const PIE_COLORS  = ['#0C3B8C','#E8520A','#2D7A1F','#C8A200','#7C3AED','#0891B2'];
const ORANGE = '#E8520A';
const BLUE   = '#0C3B8C';

const card = {
  background: '#ffffff',
  borderRadius: 8,
  border: '1px solid #e2e8f0',
  padding: '22px 24px',
  boxShadow: '0 1px 3px rgba(0,0,0,0.06), 0 2px 8px rgba(0,0,0,0.04)',
};

const sectionTitle = {
  fontSize: 13,
  fontWeight: 700,
  color: '#64748b',
  textTransform: 'uppercase',
  letterSpacing: '0.08em',
  marginBottom: 16,
  paddingBottom: 10,
  borderBottom: '1px solid #f1f5f9',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
};

// ─── Sparkline ───────────────────────────────────────────────────────────────
function Sparkline({ data, strokeColor, gradientId }) {
  const safe = data && data.length >= 2 ? data : [{ v: 0 }, { v: 0 }];
  return (
    <ResponsiveContainer width="100%" height={44}>
      <AreaChart data={safe} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={strokeColor} stopOpacity={0.3} />
            <stop offset="95%" stopColor={strokeColor} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="v" stroke={strokeColor} strokeWidth={2}
          fill={`url(#${gradientId})`} dot={false}
          activeDot={{ r: 3, fill: strokeColor, strokeWidth: 0 }} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

// ─── Stat Card ───────────────────────────────────────────────────────────────
function StatCard({ icon, label, value, sub, badge, gradient, gradientId, strokeColor, sparkData, loading }) {
  return (
    <div style={{
      background: gradient,
      borderRadius: 8,
      padding: '18px 20px 0',
      color: '#fff',
      position: 'relative',
      overflow: 'hidden',
      boxShadow: '0 4px 16px rgba(0,0,0,0.14)',
      border: '1px solid rgba(255,255,255,0.08)',
    }}>
      <div style={{ position:'absolute', top:0, right:0, width:'60%', height:'100%',
        background:'rgba(255,255,255,0.04)', clipPath:'polygon(30% 0,100% 0,100% 100%,0% 100%)' }}/>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:10 }}>
        <div>
          <p style={{ margin:0, fontSize:10, fontWeight:700, opacity:0.75, letterSpacing:'0.1em', textTransform:'uppercase' }}>{label}</p>
          <p style={{ margin:'8px 0 0', fontSize:28, fontWeight:800, lineHeight:1, letterSpacing:'-0.03em' }}>
            {loading ? '—' : value}
          </p>
          {sub   && !loading && <p style={{ margin:'5px 0 0', fontSize:11, opacity:0.7 }}>{sub}</p>}
          {badge && !loading && (
            <span style={{ display:'inline-block', marginTop:6, fontSize:10, fontWeight:700,
              background:'rgba(255,255,255,0.18)', borderRadius:4, padding:'2px 8px', letterSpacing:'0.03em' }}>
              {badge}
            </span>
          )}
        </div>
        <div style={{ width:42, height:42, borderRadius:8,
          background:'rgba(255,255,255,0.15)', border:'1px solid rgba(255,255,255,0.2)',
          display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>
          {icon}
        </div>
      </div>
      <Sparkline data={sparkData} strokeColor={strokeColor} gradientId={gradientId} />
    </div>
  );
}

// ─── Section Header ───────────────────────────────────────────────────────────
function SectionHeader({ icon, title, accent }) {
  return (
    <div style={{ ...sectionTitle }}>
      <span style={{ width:28, height:28, borderRadius:6,
        background:`${accent}15`, border:`1px solid ${accent}30`,
        display:'flex', alignItems:'center', justifyContent:'center', fontSize:14 }}>
        {icon}
      </span>
      <span style={{ color:'#1e293b', fontSize:13, fontWeight:700, letterSpacing:'0.04em', textTransform:'uppercase' }}>
        {title}
      </span>
    </div>
  );
}

// ─── Chart Tooltip ───────────────────────────────────────────────────────────
function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'#fff', border:'1px solid #e2e8f0', borderRadius:6,
      padding:'8px 14px', boxShadow:'0 4px 12px rgba(0,0,0,0.10)', fontSize:12 }}>
      <div style={{ fontWeight:700, color:'#1e293b', marginBottom:4, fontSize:11,
        textTransform:'uppercase', letterSpacing:'0.05em' }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ color:p.color, fontWeight:600, fontSize:12 }}>
          {p.name}: {p.name === 'Revenue' ? fmtINR(p.value) : fmtNum(p.value)}
        </div>
      ))}
    </div>
  );
}

const STATUS_CONFIG = [
  { key:'processing',       label:'Processing',       color:'#C8A200' },
  { key:'confirmed',        label:'Confirmed',        color:'#0891B2' },
  { key:'shipped',          label:'Shipped',          color:'#7C3AED' },
  { key:'out_for_delivery', label:'Out for Delivery', color:'#E8520A' },
  { key:'delivered',        label:'Delivered',        color:'#2D7A1F' },
  { key:'cancelled',        label:'Cancelled',        color:'#DC2626' },
  { key:'refunded',         label:'Refunded',         color:'#9CA3AF' },
];

// ════════════════════════════════════════════════════════════════════════════
export default function Dashboard({ showToast }) {
  const STORAGE_KEY = 'kalpana_low_stock_threshold';

  const [threshold, setThreshold] = useState(
    parseInt(localStorage.getItem(STORAGE_KEY)) || 10
  );

  const [baseStats,       setBaseStats]       = useState({ totalProducts: '-', totalCustomers: '-' });
  const [recentProducts,  setRecentProducts]  = useState([]);
  const [allProducts,     setAllProducts]     = useState([]);
  const [allOrders,       setAllOrders]       = useState([]);
  const [baseLoading,     setBaseLoading]     = useState(true);
  const [productsLoading, setProductsLoading] = useState(true);
  const [ordersLoading,   setOrdersLoading]   = useState(true);

  useEffect(() => {
    function onStorage(e) {
      if (e.key === STORAGE_KEY) {
        const val = parseInt(e.newValue) || 10;
        setThreshold(val);
      }
    }
    function onCustom(e) {
      setThreshold(e.detail);
    }
    window.addEventListener('storage', onStorage);
    window.addEventListener('kalpana_threshold_change', onCustom);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('kalpana_threshold_change', onCustom);
    };
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    fetch(`${API}/dashboard/stats`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(data => {
        if (data.stats)          setBaseStats(data.stats);
        if (data.recentProducts) setRecentProducts(data.recentProducts);
      })
      .catch(() => showToast?.('Failed to load dashboard stats'))
      .finally(() => setBaseLoading(false));
  }, [showToast]);

  useEffect(() => {
    fetch(`${API}/products`)
      .then(r => r.json())
      .then(data => setAllProducts(Array.isArray(data) ? data : []))
      .catch(() => showToast?.('Failed to load products'))
      .finally(() => setProductsLoading(false));
  }, [showToast]);

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    fetch(`${API}/orders/all`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(data => setAllOrders(Array.isArray(data.orders) ? data.orders : []))
      .catch(() => showToast?.('Failed to load orders'))
      .finally(() => setOrdersLoading(false));
  }, [showToast]);

  const sales = useMemo(() => {
    const delivered = allOrders.filter(o => o.status === 'delivered');
    console.log('🛒 Sample delivered order:', delivered[0]);
console.log('🛒 OrderItems:', delivered[0]?.OrderItems);
console.log('🛒 First item product_id:', delivered[0]?.OrderItems?.[0]?.product_id);
console.log('🏷️ Sample product id:', allProducts[0]?.id);
    const cancelled = allOrders.filter(o => o.status === 'cancelled');
    const refunded  = allOrders.filter(o => o.status === 'refunded');

    // ✅ o.total — DB column name
    const totalRevenue = delivered.reduce((s, o) => s + (Number(o.total) || 0), 0);
    const aov = delivered.length ? totalRevenue / delivered.length : 0;

    const now   = new Date();
    const thisM = now.getMonth();
    const thisY = now.getFullYear();

    const revOfMonth = (m, y) =>
      delivered
        .filter(o => {
          const d = new Date(o.createdAt);
          return d.getMonth() === m && d.getFullYear() === y;
        })
        .reduce((s, o) => s + (Number(o.total) || 0), 0);

    const lastM = (thisM + 11) % 12;
    const lastY = thisM === 0 ? thisY - 1 : thisY;

    const growth = revOfMonth(lastM, lastY)
      ? (((revOfMonth(thisM, thisY) - revOfMonth(lastM, lastY)) / revOfMonth(lastM, lastY)) * 100).toFixed(1)
      : 0;

    const monthlyData = [];
    for (let i = 5; i >= 0; i--) {
      const m = (thisM - i + 12) % 12;
      const y = thisM - i < 0 ? thisY - 1 : thisY;
      monthlyData.push({
        month:   MONTH_NAMES[m],
        revenue: revOfMonth(m, y),
        orders:  allOrders.filter(o => {
          const d = new Date(o.createdAt);
          return d.getMonth() === m && d.getFullYear() === y;
        }).length,
      });
    }

    const statusCounts = {};
    allOrders.forEach(o => {
      statusCounts[o.status] = (statusCounts[o.status] || 0) + 1;
    });

    return {
      totalRevenue, aov,
      ordersCount:    allOrders.length,
      deliveredCount: delivered.length,
      growth:         Number(growth),
      cancellations:  cancelled.length,
      refunds:        refunded.length,
      monthlyData,
      statusCounts,
    };
  }, [allOrders]);

  const products = useMemo(() => {
    // ✅ STRATEGY 1: Build name→id map from allProducts for name-based matching
    const nameToId = {};
    allProducts.forEach(p => {
      if (p.productName) nameToId[p.productName.toLowerCase().trim()] = p.id;
    });

    // ✅ STRATEGY 2: Count sales by product_id AND by name (dual index)
   const salesByProduct = {};
const salesByName    = {};

allOrders
  .filter(o => o.status === 'delivered')
  .forEach(o => {
    const items = o.OrderItems || o.orderItems || o.order_items || o.items || [];
    items.forEach(item => {
      const qty = Number(item.quantity) || 1;
      const pid = item.product_id || item.productId || item.ProductId || null;
      const key = (item.name || item.productName || '').toLowerCase().trim();

      if (pid) salesByProduct[String(pid)] = (salesByProduct[String(pid)] || 0) + qty;
      if (key) {
        salesByName[key] = (salesByName[key] || 0) + qty;
        if (!pid && nameToId[key]) salesByProduct[String(nameToId[key])] = (salesByProduct[String(nameToId[key])] || 0) + qty;
      }
    });
  });

    const enriched = allProducts.map(p => {
      const stock   = Number(p.stock) || 0;
      const nameKey = p.productName?.toLowerCase().trim() || '';

      // Try id match first, then name match, then DB field as last resort
      const sales =
        salesByProduct[String(p.id)] ||
        salesByName[nameKey] ||
        Number(p.salesCount ?? p.totalSales ?? 0);

      return {
        id:       p.id,
        name:     p.productName,
        category: p.Category?.name || '—',
        stock,
        sales,
        price:   Number(p.salesPrice) || 0,
        mrp:     Number(p.mrp) ?? 0,
      };
    });

    const LOW_THRESHOLD = threshold;
    const lowStock      = [];
    const outOfStock    = [];

    allProducts.forEach(p => {
      const entry = {
        productId:   p.id,
        productName: p.productName,
        category:    p.Category?.name || '—',
        stock:       Number(p.stock) || 0,
        salesPrice:  Number(p.salesPrice) || 0,
        mrp:         Number(p.mrp) || 0,
      };
      if (entry.stock === 0) {
        outOfStock.push(entry);
      } else if (entry.stock <= LOW_THRESHOLD) {
        lowStock.push(entry);
      }
    });
    lowStock.sort((a, b) => a.stock - b.stock);

    const byCategory = {};
    enriched.forEach(p => {
      if (!byCategory[p.category])
        byCategory[p.category] = { name: p.category, products: 0, stock: 0, sales: 0 };
      byCategory[p.category].products++;
      byCategory[p.category].stock += p.stock;
      byCategory[p.category].sales += p.sales;
    });

    return {
      enriched,
      bestSelling:   [...enriched].sort((a, b) => b.sales - a.sales).slice(0, 5),
      lowStock:      lowStock,
      outOfStock:    outOfStock,
      topPerformers: [...enriched].sort((a, b) => b.sales - a.sales).slice(0, 6),
      categoryData:  Object.values(byCategory).sort((a, b) => b.products - a.products).slice(0, 6),
      totalStock:    enriched.reduce((s, p) => s + p.stock, 0),
      highStock:     enriched.filter(p => p.stock > 200).length,
    };
  }, [allProducts, allOrders, threshold]);

  const revSpark  = sales.monthlyData.map(m => ({ v: m.revenue }));
  const ordSpark  = sales.monthlyData.map(m => ({ v: m.orders }));
  const prdSpark  = [30,45,38,52,48,60,55,70].map(v => ({ v }));
  const custSpark = [20,35,28,40,38,55,50,65].map(v => ({ v }));

  return (
    <div style={{ padding:'24px 28px', fontFamily:'"Inter","Plus Jakarta Sans",sans-serif',
      background:'#f8fafc', minHeight:'100vh', display:'flex', flexDirection:'column', gap:20 }}>

      {/* ── PAGE TITLE BAR ─────────────────────────────────────────────── */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
        paddingBottom:16, borderBottom:'1px solid #e2e8f0' }}>
        <div>
          <h1 style={{ margin:0, fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.02em' }}>
            Dashboard
          </h1>
          <p style={{ margin:'3px 0 0', fontSize:12, color:'#94a3b8' }}>
            Overview of sales, orders and inventory
          </p>
        </div>
        <div style={{ fontSize:11, color:'#94a3b8', fontWeight:500,
          background:'#fff', border:'1px solid #e2e8f0', borderRadius:6, padding:'6px 12px' }}>
          {new Date().toLocaleDateString('en-IN', { weekday:'short', year:'numeric', month:'short', day:'numeric' })}
        </div>
      </div>

      {/* ── TOP STAT CARDS ─────────────────────────────────────────────── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(180px, 1fr))', gap:14 }}>
        <StatCard icon="💰" label="Total Revenue"   loading={ordersLoading}   value={fmtINR(sales.totalRevenue)} sub={`${sales.deliveredCount} delivered`}          sparkData={revSpark}  gradientId="spRev"  strokeColor="#FFB347" gradient="linear-gradient(135deg,#E8520A,#C93A08)"/>
        <StatCard icon="📦" label="Total Orders"    loading={ordersLoading}   value={fmtNum(sales.ordersCount)}  badge={`${sales.cancellations} cancelled`}          sparkData={ordSpark}  gradientId="spOrd"  strokeColor="#7EC8F8" gradient="linear-gradient(135deg,#1A6DC4,#0C3B8C)"/>
        <StatCard icon="📊" label="Avg Order Value" loading={ordersLoading}   value={fmtINR(sales.aov)}          sub="per delivered order"                           sparkData={revSpark}  gradientId="spAov"  strokeColor="#C4B5FD" gradient="linear-gradient(135deg,#7C3AED,#5B21B6)"/>
        <StatCard icon="🛍️" label="Total Products" loading={productsLoading} value={fmtNum(allProducts.length)} sub={`${products.outOfStock.length} out of stock`}  sparkData={prdSpark}  gradientId="spProd" strokeColor="#86EFAC" gradient="linear-gradient(135deg,#2D7A1F,#1F5A15)"/>
        <StatCard icon="👥" label="Total Customers" loading={baseLoading}     value={fmtNum(baseStats.totalCustomers)}                                                sparkData={custSpark} gradientId="spCust" strokeColor="#7DD3FC" gradient="linear-gradient(135deg,#0891B2,#0369A1)"/>
      </div>

      {/* ── SPLIT: SALES | PRODUCTS ─────────────────────────────────────── */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, alignItems:'start' }}>

        {/* ══ LEFT: SALES ═════════════════════════════════════════════════ */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:3, height:18, background:BLUE, borderRadius:2 }}/>
            <span style={{ fontSize:12, fontWeight:700, color:'#1e293b', letterSpacing:'0.06em', textTransform:'uppercase' }}>
              Sales Overview
            </span>
          </div>

          {/* KPI row */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10 }}>
            {[
              { label:'MoM Growth',    value: ordersLoading ? '—' : `${sales.growth > 0 ? '+' : ''}${sales.growth}%`, sub:'vs last month',   color: ordersLoading ? '#94a3b8' : growthColor(sales.growth) },
              { label:'Cancellations', value: ordersLoading ? '—' : fmtNum(sales.cancellations),                       sub:'orders cancelled', color:'#DC2626' },
              { label:'Refunds',       value: ordersLoading ? '—' : fmtNum(sales.refunds),                             sub:'orders refunded',  color:'#7C3AED' },
            ].map(c => (
              <div key={c.label} style={{ ...card, padding:'14px 16px', borderTop:`3px solid ${c.color}` }}>
                <p style={{ margin:0, fontSize:9, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.08em' }}>{c.label}</p>
                <span style={{ fontSize:22, fontWeight:800, color:c.color, display:'block', margin:'6px 0 2px', letterSpacing:'-0.02em' }}>{c.value}</span>
                <p style={{ margin:0, fontSize:10, color:'#94a3b8' }}>{c.sub}</p>
              </div>
            ))}
          </div>

          {/* Area chart */}
          <div style={card}>
            <SectionHeader icon="📈" title="Revenue & Orders — Last 6 Months" accent={BLUE}/>
            {ordersLoading ? (
              <div style={{ height:190, display:'flex', alignItems:'center', justifyContent:'center', color:'#94a3b8', fontSize:12 }}>Loading…</div>
            ) : (
              <ResponsiveContainer width="100%" height={190}>
                <AreaChart data={sales.monthlyData} margin={{ top:6, right:14, left:0, bottom:0 }}>
                  <defs>
                    <linearGradient id="gRev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor={ORANGE} stopOpacity={0.25}/>
                      <stop offset="95%" stopColor={ORANGE} stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="gOrd" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor={BLUE} stopOpacity={0.2}/>
                      <stop offset="95%" stopColor={BLUE} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9"/>
                  <XAxis dataKey="month" tick={{ fontSize:10, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
                  <YAxis yAxisId="rev" tick={{ fontSize:9, fill:'#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `₹${(v/1000).toFixed(0)}k` : `₹${v}`}/>
                  <YAxis yAxisId="ord" orientation="right" tick={{ fontSize:9, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
                  <Tooltip content={<ChartTooltip/>}/>
                  <Legend wrapperStyle={{ fontSize:11, paddingTop:8 }}/>
                  <Area yAxisId="rev" type="monotone" dataKey="revenue" name="Revenue" stroke={ORANGE} strokeWidth={2} fill="url(#gRev)" dot={false}/>
                  <Area yAxisId="ord" type="monotone" dataKey="orders"  name="Orders"  stroke={BLUE}  strokeWidth={2} fill="url(#gOrd)"  dot={false}/>
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Status breakdown */}
          <div style={card}>
            <SectionHeader icon="🔄" title="Order Status Breakdown" accent={ORANGE}/>
            {ordersLoading ? (
              <div style={{ color:'#94a3b8', textAlign:'center', padding:20, fontSize:12 }}>Loading…</div>
            ) : (
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(88px,1fr))', gap:8 }}>
                {STATUS_CONFIG.map(({ key, label, color }) => {
                  const cnt = sales.statusCounts[key] || 0;
                  const pct = sales.ordersCount ? ((cnt / sales.ordersCount) * 100).toFixed(0) : 0;
                  return (
                    <div key={key} style={{ background:'#f8fafc', border:`1px solid ${color}25`,
                      borderTop:`3px solid ${color}`, borderRadius:6, padding:'10px 12px' }}>
                      <div style={{ fontSize:18, fontWeight:800, color, lineHeight:1 }}>{cnt}</div>
                      <div style={{ fontSize:10, fontWeight:600, color:'#475569', marginTop:4, lineHeight:1.3 }}>{label}</div>
                      <div style={{ fontSize:10, color:'#94a3b8', marginTop:2 }}>{pct}%</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* ══ RIGHT: PRODUCTS ═════════════════════════════════════════════ */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:3, height:18, background:ORANGE, borderRadius:2 }}/>
            <span style={{ fontSize:12, fontWeight:700, color:'#1e293b', letterSpacing:'0.06em', textTransform:'uppercase' }}>
              Product Overview
            </span>
          </div>

          {/* Pills */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:8 }}>
            {[
              { label:'Total',        value: allProducts.length,          icon:'🏷️', color:BLUE      },
              { label:'High Stock',   value: products.highStock,          icon:'✅', color:'#2D7A1F'  },
              { label:'Low Stock',   value: products.lowStock.length,    icon:'⚠️', color:'#E8520A'  },
              { label:'Out of Stock', value: products.outOfStock.length,  icon:'❌', color:'#DC2626'  },
              { label:'Total Units',  value: fmtNum(products.totalStock), icon:'📦', color:'#7C3AED'  },
            ].map(s => (
              <div key={s.label} style={{ ...card, padding:'12px 10px', borderTop:`3px solid ${s.color}`,
                display:'flex', flexDirection:'column', gap:3, alignItems:'center', textAlign:'center' }}>
                <span style={{ fontSize:16 }}>{s.icon}</span>
                <span style={{ fontSize:18, fontWeight:800, color:s.color, lineHeight:1 }}>
                  {productsLoading ? '—' : s.value}
                </span>
                <span style={{ fontSize:9, color:'#94a3b8', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.04em' }}>{s.label}</span>
              </div>
            ))}
          </div>

          {/* Best Selling + Low Stock */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div style={card}>
              <SectionHeader icon="🏆" title="Best-Selling" accent={ORANGE}/>
              {productsLoading || ordersLoading ? (
                <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>Loading…</div>
              ) : products.bestSelling.length === 0 ? (
                <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>No sales data yet.</div>
              ) : products.bestSelling.map((p, i) => (
                <div key={p.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 0',
                  borderBottom: i < products.bestSelling.length-1 ? '1px solid #f1f5f9' : 'none' }}>
                  <div style={{ width:22, height:22, borderRadius:4, flexShrink:0, fontSize:11,
                    background: i===0?'#FEF3C7':i===1?'#F1F5F9':i===2?'#FEF9EE':'#F8FAFC',
                    color:      i===0?'#D97706':i===1?'#64748B':i===2?'#E8520A':'#94a3b8',
                    display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800 }}>
                    {i < 3 ? ['🥇','🥈','🥉'][i] : `${i+1}`}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:11, fontWeight:600, color:'#0f172a', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{p.name}</div>
                    <div style={{ fontSize:9, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.03em' }}>{p.category}</div>
                  </div>
                  <div style={{ fontSize:10, fontWeight:700, color:ORANGE, flexShrink:0 }}>{fmtNum(p.sales)} sold</div>
                </div>
              ))}
            </div>

            <div style={card}>
              <SectionHeader icon="⚠️" title={`Low Stock (≤ ${threshold} units)`} accent="#C8A200"/>
              {productsLoading ? (
                <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>Loading…</div>
              ) : products.lowStock.length === 0 ? (
                <div style={{ color:'#2D7A1F', fontWeight:600, padding:12, fontSize:12 }}>✅ All good!</div>
              ) : (
                <div style={{ overflowY:'auto', maxHeight:200 }}>
                  {products.lowStock.map((v, i) => (
                    <div key={v.productId} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0',
                      borderBottom: i < products.lowStock.length-1 ? '1px solid #f1f5f9' : 'none' }}>
                      <span style={{ width:6, height:6, borderRadius:'50%', background:stockColor(v.stock), flexShrink:0 }}/>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:11, fontWeight:600, color:'#0f172a', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{v.productName}</div>
                        <div style={{ fontSize:9, color:'#64748b', marginTop:1 }}>{v.category}</div>
                      </div>
                      <span style={{ fontSize:10, fontWeight:700, padding:'1px 7px', borderRadius:4, flexShrink:0,
                        background:`${stockColor(v.stock)}15`, color:stockColor(v.stock),
                        border:`1px solid ${stockColor(v.stock)}30` }}>
                        {v.stock} left
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Bar + Pie */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div style={card}>
              <SectionHeader icon="📊" title="Performance" accent={BLUE}/>
              {productsLoading || ordersLoading ? (
                <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>Loading…</div>
              ) : (
                <ResponsiveContainer width="100%" height={170}>
                  <BarChart data={products.topPerformers.map(p => ({
                    name: p.name.length>10 ? p.name.slice(0,9)+'…' : p.name,
                    Sales: p.sales, Stock: p.stock
                  }))} margin={{ top:4, right:4, left:0, bottom:26 }}>
                    <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9"/>
                    <XAxis dataKey="name" tick={{ fontSize:8, fill:'#94a3b8' }} angle={-30} textAnchor="end" interval={0} axisLine={false} tickLine={false}/>
                    <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
                    <Tooltip/>
                    <Legend wrapperStyle={{ fontSize:9 }}/>
                    <Bar dataKey="Sales" fill={ORANGE} radius={[3,3,0,0]}/>
                    <Bar dataKey="Stock" fill={BLUE}   radius={[3,3,0,0]}/>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>

            <div style={card}>
              <SectionHeader icon="🗂️" title="Categories" accent="#7C3AED"/>
              {productsLoading ? (
                <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>Loading…</div>
              ) : products.categoryData.length === 0 ? (
                <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>No categories.</div>
              ) : (
                <>
                  <ResponsiveContainer width="100%" height={130}>
                    <PieChart>
                      <Pie data={products.categoryData} dataKey="products" nameKey="name"
                        cx="50%" cy="50%" outerRadius={55} innerRadius={28} paddingAngle={2}
                        label={({ percent }) => percent > 0.08 ? `${(percent*100).toFixed(0)}%` : ''} labelLine={false}>
                        {products.categoryData.map((_, idx) => <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]}/>)}
                      </Pie>
                      <Tooltip formatter={(val, _, props) => [`${val} products`, props.payload.name]}/>
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display:'flex', flexWrap:'wrap', gap:'3px 10px', marginTop:6 }}>
                    {products.categoryData.map((cat, idx) => (
                      <div key={cat.name} style={{ display:'flex', alignItems:'center', gap:4 }}>
                        <span style={{ width:6, height:6, borderRadius:'50%', background:PIE_COLORS[idx%PIE_COLORS.length], flexShrink:0 }}/>
                        <span style={{ fontSize:9, color:'#475569', fontWeight:600 }}>{cat.name} ({cat.products})</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Out of Stock */}
          <div style={card}>
            <SectionHeader icon="❌" title="Out-of-Stock Products" accent="#DC2626"/>
            {productsLoading ? (
              <div style={{ color:'#94a3b8', textAlign:'center', padding:16, fontSize:12 }}>Loading…</div>
            ) : products.outOfStock.length === 0 ? (
              <div style={{ color:'#2D7A1F', fontWeight:600, fontSize:12, display:'flex', alignItems:'center', gap:6 }}>
                ✅ All products are currently in stock.
              </div>
            ) : (
              <div style={{ overflowX:'auto' }}>
                <table style={{ width:'100%', borderCollapse:'collapse', fontSize:11 }}>
                  <thead>
                    <tr style={{ background:'#fef2f2' }}>
                      {['Product','Category','Sale Price','Status'].map(h => (
                        <th key={h} style={{ textAlign:'left', padding:'7px 10px', fontSize:9,
                          fontWeight:700, color:'#DC2626', borderBottom:'1px solid #fecaca',
                          textTransform:'uppercase', letterSpacing:'0.06em', whiteSpace:'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {products.outOfStock.map((v, i) => (
                      <tr key={v.productId} style={{ borderBottom:'1px solid #f8fafc', background: i%2===0?'#fff':'#fafafa' }}>
                        <td style={{ padding:'8px 10px', fontWeight:600, color:'#0f172a' }}>{v.productName}</td>
                        <td style={{ padding:'8px 10px' }}>
                          <span style={{ background:'#fee2e2', color:'#DC2626', borderRadius:4,
                            padding:'2px 6px', fontSize:9, fontWeight:700, textTransform:'uppercase' }}>{v.category}</span>
                        </td>
                        <td style={{ padding:'8px 10px', fontWeight:700, color:ORANGE }}>{fmtINR(v.salesPrice)}</td>
                        <td style={{ padding:'8px 10px' }}>
                          <span style={{ fontSize:9, fontWeight:700, background:'#fee2e2', color:'#DC2626',
                            padding:'2px 8px', borderRadius:4, border:'1px solid #fca5a5',
                            textTransform:'uppercase', letterSpacing:'0.04em' }}>Restock</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── RECENT PRODUCTS ─────────────────────────────────────────────── */}
      <div style={card}>
        <SectionHeader icon="🆕" title="Recent Products" accent={BLUE}/>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <thead>
              <tr style={{ background:'#f8fafc', borderBottom:'1px solid #e2e8f0' }}>
                {['Product Name','Category','MRP (₹)','Sale Price (₹)','Stock','Status'].map(h => (
                  <th key={h} style={{ textAlign:'left', padding:'9px 12px', fontWeight:700,
                    fontSize:10, color:'#64748b', whiteSpace:'nowrap',
                    textTransform:'uppercase', letterSpacing:'0.06em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {!baseLoading && recentProducts.length === 0 ? (
                <tr><td colSpan={6} style={{ padding:24, color:'#94a3b8', textAlign:'center', fontSize:12 }}>No products yet.</td></tr>
              ) : recentProducts.map((p, i) => {
                const totalStock = Number(p.stock) || 0;
                const mrp   = Number(p.mrp) || 0;
                const price = Number(p.salesPrice) || 0;
                return (
                  <tr key={p.id} style={{ borderBottom:'1px solid #f1f5f9',
                    background: i%2===0 ? '#fff' : '#fafbfc' }}>
                    <td style={{ padding:'10px 12px', fontWeight:600, color:'#0f172a',
                      maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.productName}</td>
                    <td style={{ padding:'10px 12px' }}>
                      <span style={{ background:'#eff6ff', color:BLUE, borderRadius:4,
                        padding:'2px 8px', fontSize:10, fontWeight:700,
                        textTransform:'uppercase', letterSpacing:'0.03em' }}>{p.Category?.name||'—'}</span>
                    </td>
                    <td style={{ padding:'10px 12px', color:'#94a3b8', textDecoration:'line-through', fontSize:11 }}>₹{mrp}</td>
                    <td style={{ padding:'10px 12px', fontWeight:800, color:ORANGE }}>{fmtINR(price)}</td>
                    <td style={{ padding:'10px 12px' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                        <span style={{ width:7, height:7, borderRadius:'50%', background:stockColor(totalStock), flexShrink:0 }}/>
                        <span style={{ fontWeight:700, color:'#0f172a' }}>{totalStock}</span>
                      </div>
                    </td>
                    <td style={{ padding:'10px 12px' }}>
                      <span style={{ fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:4,
                        background:`${stockColor(totalStock)}12`, color:stockColor(totalStock),
                        border:`1px solid ${stockColor(totalStock)}30`,
                        textTransform:'uppercase', letterSpacing:'0.04em' }}>
                        {stockLabel(totalStock)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={{ display:'flex', flexWrap:'wrap', gap:'6px 16px', marginTop:12,
          paddingTop:10, borderTop:'1px solid #f1f5f9' }}>
          {[['#2D7A1F','High (>200)'],['#C8A200','Medium (51–200)'],['#E8520A','Low (≤50)'],['#DC2626','Out of stock']].map(([c,l]) => (
            <div key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
              <span style={{ width:7, height:7, borderRadius:'50%', background:c, flexShrink:0 }}/>
              <span style={{ fontSize:10, color:'#94a3b8', fontWeight:500 }}>{l}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}