import { useState, useEffect } from 'react';
import DataTable from '../DataTable/DataTable';

const API = process.env.REACT_APP_API_URL;

const getImageUrl = (imagePath) => {
  if (!imagePath) return null;
  if (imagePath.startsWith('http')) return imagePath;
  const filename = imagePath.replace(/^\//, '').replace(/^uploads\//, '');
  return `${API}/uploads/${filename}`;
};

export default function Categories({ showToast }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [categoryName, setCategoryName] = useState('');
  const [imageFile, setImageFile] = useState(null);

  useEffect(() => { fetchCategories(); }, []);

  const fetchCategories = () => {
    setLoading(true);
    fetch(`${API}/categories`)
      .then(r => r.json())
      .then(data => { setRows(data); setLoading(false); })
      .catch(() => { showToast('Load Failed', 'Could not load categories.'); setLoading(false); });
  };

  const handleEditClick = (cat) => {
    setEditingId(cat.id); setCategoryName(cat.name);
    setImageFile(null); setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!categoryName) { showToast('Missing Name', 'Please enter a category name.'); return; }
    const data = new FormData();
    data.append('name', categoryName);
    if (imageFile) data.append('image', imageFile);
    const method = editingId ? 'PUT' : 'POST';
    const url = editingId ? `${API}/categories/update/${editingId}` : `${API}/categories/add`;
    try {
      const res = await fetch(url, { method, body: data });
      if (res.ok) {
        showToast(editingId ? 'Updated!' : 'Added!', editingId ? 'Category updated successfully.' : 'New category added.');
        resetForm(); fetchCategories();
      } else { showToast('Failed', 'Operation could not be completed.'); }
    } catch { showToast('Server Error', 'Something went wrong. Try again.'); }
  };

  const resetForm = () => {
    setShowForm(false); setEditingId(null);
    setCategoryName(''); setImageFile(null);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this category?')) return;
    try {
      const res = await fetch(`${API}/categories/delete/${id}`, { method: 'DELETE' });
      if (res.ok) { setRows(prev => prev.filter(r => r.id !== id)); showToast('Deleted!', 'Category removed successfully.'); }
    } catch { showToast('Delete Failed', 'Could not delete category.'); }
  };

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Categories</div>
        <button className="action-btn btn-edit"
          onClick={() => { if (showForm) resetForm(); else setShowForm(true); }}>
          {showForm ? 'Close' : '+ Add Category'}
        </button>
      </div>

      {showForm && (
        <div className="km-form-card">
          <div className="km-form-header">
            <div className="km-form-header-icon">C</div>
            <div>
              <div className="km-form-header-title">{editingId ? 'Edit Category' : 'Add New Category'}</div>
              <div className="km-form-header-sub">Fill in the details below</div>
            </div>
          </div>

          <div className="km-form-body">
            <form className="km-form-grid" onSubmit={handleSubmit}>

              <div className="km-field km-field-full">
                <label className="km-label">Category Name</label>
                <input className="km-input" type="text" placeholder="e.g. Electronics" required
                  value={categoryName} onChange={e => setCategoryName(e.target.value)} />
              </div>

              <div className="km-field km-field-full">
                <label className="km-label">
                  Category Image {editingId && '(Leave blank to keep current)'}
                </label>
                <div className="km-file-zone">
                  <div className="km-file-icon">↑</div>
                  {imageFile
                    ? <p className="km-file-selected">✓ {imageFile.name}</p>
                    : <p className="km-file-label">Click to upload image</p>}
                  <input type="file" accept="image/*" onChange={e => setImageFile(e.target.files[0])} />
                </div>
              </div>

              <button type="submit" className="km-btn-submit">
                {editingId ? 'Update Category' : 'Save Category'}
              </button>
              <button type="button" className="km-btn-cancel" onClick={resetForm}>Cancel</button>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <p className="km-loading">Loading categories...</p>
      ) : (
        <DataTable
          columns={['ID', 'Image', 'Category Name', 'Actions']}
          initialRows={rows}
          renderRow={(row) => (
            <tr key={row.id}>
              <td className="td-id">#{row.id}</td>
              <td>
                <div className="img-thumb">
                  {row.image
                    ? <img src={getImageUrl(row.image)} alt={row.name} width="40" height="40"
                        onError={e => { e.target.src = 'https://via.placeholder.com/40?text=No+Img'; }} />
                    : '🗂️'}
                </div>
              </td>
              <td>{row.name}</td>
              <td>
                <button className="action-btn btn-edit" onClick={() => handleEditClick(row)}>Edit</button>
                <button className="action-btn btn-del" onClick={() => handleDelete(row.id)}>Delete</button>
              </td>
            </tr>
          )}
        />
      )}
    </div>
  );
}