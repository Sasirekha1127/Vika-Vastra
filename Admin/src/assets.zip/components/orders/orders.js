import { useState, useEffect, useCallback } from 'react';
import DataTable from '../DataTable/DataTable';

const API = process.env.REACT_APP_API_URL;

const STATUS_OPTIONS = [
  'confirmed', 'shipped',
  'out_for_delivery', 'delivered', 'cancelled'
];
const labelFor = s => s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

const parseAddr = (raw) => { try { return JSON.parse(raw); } catch { return null; } };

const AddressBlock = ({ addr, phone, phone2, email }) => {
  if (!addr) return <p className="td-muted">Not provided</p>;

  return (
    <div className="km-billing-info">
      <div>
        <strong>{addr.firstName} {addr.lastName}</strong>
      </div>

      {addr.company && (
        <div className="td-muted">{addr.company}</div>
      )}

      <div>{addr.address1}</div>

      {addr.address2 && <div>{addr.address2}</div>}

      <div>
        {addr.city}{addr.state ? `, ${addr.state}` : ""}
      </div>

      {addr.postcode && <div>PIN: {addr.postcode}</div>}

      <div>📞 {addr.phone || phone}</div>

      {/* Second phone number */}
      {(addr.phone2 || phone2) && (
        <div>📞 {addr.phone2 || phone2} <span style={{
          fontSize: 10, fontWeight: 600, background: '#fff3e0',
          color: '#e65100', padding: '1px 6px', borderRadius: 10, marginLeft: 4,
        }}>Alt</span></div>
      )}

      {email && <div>✉️ {addr.email || email}</div>}
    </div>
  );
};

export default function Orders({ showToast, status = null }) {
  const [rows,        setRows]        = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [expanded,    setExpanded]    = useState(null);
  const [updatingIds, setUpdatingIds] = useState(new Set());

  const fetchOrders = useCallback((currentStatus) => {
    setLoading(true);
    fetch(`${API}/orders/all`)
      .then(r => r.json())
      .then(data => {
        const all = Array.isArray(data.orders) ? data.orders : [];
        setRows(currentStatus ? all.filter(o => o.status === currentStatus) : all);
      })
      .catch(() => showToast('Load Failed', 'Could not load orders.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    setExpanded(null);
    fetchOrders(status);
  }, [status]);

  const updateStatus = async (id, newStatus, prevStatus) => {
    setRows(prev => prev.map(o => o.id === id ? { ...o, status: newStatus } : o));
    setUpdatingIds(prev => new Set(prev).add(id));

    try {
      const res = await fetch(`${API}/orders/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!res.ok) {
        setRows(prev => prev.map(o => o.id === id ? { ...o, status: prevStatus } : o));
        showToast('Update Failed', 'Could not update order status.');
        return;
      }

      if (status && newStatus !== status) {
        setRows(prev => prev.filter(o => o.id !== id));
      }

      showToast('Order Updated!', 'Order status changed successfully.');
    } catch {
      setRows(prev => prev.map(o => o.id === id ? { ...o, status: prevStatus } : o));
      showToast('Server Error', 'Something went wrong. Try again.');
    } finally {
      setUpdatingIds(prev => { const s = new Set(prev); s.delete(id); return s; });
    }
  };

  return (
    <div>
      <div className="section-header">
        <div className="section-title">
          {status ? `${labelFor(status)} Orders` : 'All Orders'}
        </div>
        {!loading && <span className="km-count-badge">{rows.length}</span>}
      </div>

      {loading ? (
        <p className="km-loading">Loading orders...</p>
      ) : rows.length === 0 ? (
        <p className="km-empty">No orders found.</p>
      ) : (
        <DataTable
          columns={['#ID', 'Customer', 'Items', 'Total', 'Coupon', 'Status', 'Date', 'Details']}
          initialRows={rows}
          renderRow={(order) => {
            const billing      = parseAddr(order.billing_address);
            const shipping     = parseAddr(order.shipping_address);
            const isOpen       = expanded === order.id;
            const shippingAddr = shipping || billing;
            const sameAddress  = !shipping ||
              JSON.stringify(shipping) === JSON.stringify(billing);
            const isSaving     = updatingIds.has(order.id);

            // Payment breakdown
            const subtotal       = Number(order.subtotal       || 0);
            const tax            = Number(order.tax            || 0);
            const deliveryCharge = Number(order.delivery_charge || 0);
            const discount       = Number(order.discount       || 0);
            const total          = Number(order.total          || 0);

            return (
              <>
                <tr key={order.id}>
                  <td className="td-id">#{order.id}</td>

                  <td>
                    <div className="td-name">{order.customer_name}</div>
                    <div className="td-sub">{order.customer_email}</div>
                    <div className="td-sub">📞 {order.customer_phone}</div>
                    {order.customer_phone2 && (
                      <div className="td-sub">📞 {order.customer_phone2}{' '}
                        <span style={{
                          fontSize: 10, fontWeight: 600, background: '#fff3e0',
                          color: '#e65100', padding: '1px 5px', borderRadius: 10,
                        }}>Alt</span>
                      </div>
                    )}
                  </td>

                  <td>
                    <span className="km-count-badge">
                      {order.OrderItems?.length || 0} items
                    </span>
                  </td>

                  <td className="td-price">₹{total.toFixed(2)}</td>

                  <td>
                    {order.coupon_code
                      ? <span className="status-pill pill-approved">{order.coupon_code}</span>
                      : <span className="td-muted">—</span>}
                  </td>

                  <td>
                    <div style={{ position: 'relative', display: 'inline-block' }}>
                      <select
                        className={`km-status-select km-status-${order.status}`}
                        value={order.status}
                        disabled={isSaving}
                        onChange={e => updateStatus(order.id, e.target.value, order.status)}
                        style={{ opacity: isSaving ? 0.6 : 1 }}
                      >
                        {STATUS_OPTIONS.map(st => (
                          <option key={st} value={st}>{labelFor(st)}</option>
                        ))}
                      </select>
                      {isSaving && (
                        <span style={{
                          position: 'absolute', right: -22, top: '50%',
                          transform: 'translateY(-50%)',
                          width: 14, height: 14,
                          border: '2px solid #ddd',
                          borderTop: '2px solid #1A52A8',
                          borderRadius: '50%',
                          display: 'inline-block',
                          animation: 'spin 0.7s linear infinite',
                        }} />
                      )}
                    </div>
                    <style>{`@keyframes spin { to { transform: translateY(-50%) rotate(360deg); } }`}</style>
                  </td>

                  <td className="td-muted">
                    {new Date(order.createdAt).toLocaleDateString('en-IN', {
                      day: 'numeric', month: 'short', year: 'numeric'
                    })}
                  </td>

                  <td>
                    <button
                      className="action-btn btn-edit"
                      onClick={() => setExpanded(isOpen ? null : order.id)}
                    >
                      {isOpen ? '▲ Hide' : '▼ View'}
                    </button>
                  </td>
                </tr>

                {isOpen && (
                  <tr key={`${order.id}-detail`}>
                    <td colSpan={8} className="km-order-detail-cell">
                      <div className="km-form-card">
                        <div className="km-form-header">
                          <div className="km-form-header-icon">📦</div>
                          <div>
                            <div className="km-form-header-title">
                              Order #{order.id} — {order.customer_name}
                            </div>
                            <div className="km-form-header-sub">
                              Payment ID: {order.payment_id || '—'}
                            </div>
                          </div>
                        </div>

                        <div className="km-order-detail-grid"
                          style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>

                          {/* ── Items Ordered ── */}
                          <div>
                            <div className="km-detail-section-title">Items Ordered</div>
                            {order.OrderItems?.length > 0
                              ? order.OrderItems.map((item, i) => (
                                  <div key={i} className="km-order-item-row">
                                    <span>
                                      {item.name}
                                      {item.weight && (
                                        <span style={{
                                          marginLeft: 5, fontSize: 10, fontWeight: 700,
                                          background: '#e8f0ff', color: '#1A52A8',
                                          padding: '1px 6px', borderRadius: 10,
                                          whiteSpace: 'nowrap',
                                        }}>
                                          {item.weight}
                                        </span>
                                      )}
                                      <span className="td-muted"> × {item.quantity}</span>
                                    </span>
                                    <span className="td-price-sm">
                                      ₹{(item.price * item.quantity).toFixed(2)}
                                    </span>
                                  </div>
                                ))
                              : <p className="td-muted">No items found</p>}
                          </div>

                          {/* ── Billing Address ── */}
                          <div>
                            <div className="km-detail-section-title">Billing Address</div>
                            <AddressBlock
                              addr={billing}
                              phone={order.customer_phone}
                              phone2={order.customer_phone2}
                              email={order.customer_email}
                            />
                          </div>

                          {/* ── Shipping Address ── */}
                          <div>
                            <div className="km-detail-section-title">
                              Shipping Address
                              {sameAddress && (
                                <span style={{
                                  marginLeft: 8, fontSize: 11, fontWeight: 600,
                                  background: '#e8f5e9', color: '#2e7d32',
                                  padding: '2px 8px', borderRadius: 20,
                                }}>Same as billing</span>
                              )}
                            </div>
                            <AddressBlock
                              addr={shippingAddr}
                              phone={!sameAddress ? order.customer_phone : null}
                              phone2={!sameAddress ? order.customer_phone2 : null}
                              email={null}
                            />
                          </div>

                          {/* ── Payment Summary ── */}
                          <div>
                            <div className="km-detail-section-title">Payment Summary</div>

                            {/* Subtotal */}
                            <div className="km-payment-row">
                              <span className="td-muted">Subtotal</span>
                              <span>₹{subtotal.toFixed(2)}</span>
                            </div>

                            {/* GST */}
                            {tax > 0 && (
                              <div className="km-payment-row">
                                <span className="td-muted">
                                  GST (5%)
                                </span>
                                <span>+₹{tax.toFixed(2)}</span>
                              </div>
                            )}

                            {/* Delivery Charge */}
                            <div className="km-payment-row">
                              <span className="td-muted">Delivery</span>
                              {deliveryCharge > 0 ? (
                                <span>+₹{deliveryCharge.toFixed(2)}</span>
                              ) : (
                                <span className="td-green">FREE</span>
                              )}
                            </div>

                            {/* Discount */}
                            {discount > 0 && (
                              <div className="km-payment-row">
                                <span className="td-muted">
                                  Discount{order.coupon_code ? ` (${order.coupon_code})` : ''}
                                </span>
                                <span className="td-green">−₹{discount.toFixed(2)}</span>
                              </div>
                            )}

                            {/* Divider */}
                            <div style={{
                              borderTop: '1px solid #e5e7eb',
                              margin: '8px 0',
                            }} />

                            {/* Total */}
                            <div className="km-payment-total">
                              <span>Total Paid</span>
                              <span className="td-price">₹{total.toFixed(2)}</span>
                            </div>

                            {/* Order Notes */}
                            {order.order_notes && (
                              <div className="km-order-notes">
                                {order.order_notes}
                              </div>
                            )}
                          </div>

                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </>
            );
          }}
        />
      )}
    </div>
  );
}