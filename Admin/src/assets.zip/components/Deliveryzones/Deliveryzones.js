// src/components/Deliveryzones/Deliveryzones.js
import React, { useState, useEffect, useCallback } from 'react';

const API_BASE_URL = process.env.REACT_APP_API_URL;

const INDIAN_STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
  'Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka',
  'Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram',
  'Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana',
  'Tripura','Uttar Pradesh','Uttarakhand','West Bengal',
  'Andaman and Nicobar Islands','Chandigarh','Dadra and Nagar Haveli and Daman and Diu',
  'Delhi','Jammu and Kashmir','Ladakh','Lakshadweep','Puducherry'
];

const DZ_STYLES = `
  .dz-page { padding: 24px; background: #F0F4FA; min-height: 100vh; font-family: inherit; }
  .dz-card { background: #fff; border-radius: 12px; border: 1px solid #e5e7eb; overflow: hidden; }
  .dz-table { width: 100%; border-collapse: collapse; }
  .dz-table thead tr { background: #fff; }
  .dz-table th { padding: 12px 16px; text-align: left; font-size: 12px; font-weight: 600; color: #6b7280; border-bottom: 1px solid #e5e7eb; }
  .dz-table td { padding: 12px 16px; font-size: 13px; color: #374151; border-bottom: 1px solid #f3f4f6; background: #fff; vertical-align: middle; }
  .dz-table tbody tr:last-child td { border-bottom: none; }
  .dz-table tbody tr:hover td { background: #f9fafb; }
  .dz-search { flex:1; min-width:180px; padding: 9px 14px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 13px; outline: none; color: #111827; background: #fff; }
  .dz-search:focus { border-color: #9ca3af; }
  .dz-btn-add { padding: 9px 18px; background: #0C3B8C; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 6px; white-space: nowrap; }
  .dz-btn-add:hover { opacity: .88; }
  .dz-btn-add:disabled { opacity: .45; cursor: not-allowed; }
  .dz-controls { display: flex; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; align-items: center; }
  .dz-stats { display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap; }
  .dz-stat { background:#fff; border-radius:8px; padding:12px 18px; flex:1; min-width:120px; border:1px solid #E5E7EB; }
  .dz-stat-val { font-size:22px; font-weight:600; color:#111827; line-height:1; }
  .dz-stat-lbl { font-size:11px; color:#9CA3AF; margin-top:4px; text-transform:uppercase; letter-spacing:.05em; }
  .dz-badge { display:inline-flex; align-items:center; gap:4px; padding:2px 9px; border-radius:20px; font-size:11px; font-weight:600; }
  .dz-badge-active { background:#ECFDF5; color:#065F46; }
  .dz-badge-inactive { background:#FFF7ED; color:#9A3412; }
  .dz-charge { font-size: 13px; font-weight: 600; color: #374151; }
  .dz-charge-free { color: #065F46; }
  .dz-act-row { display:flex; gap:6px; }
  .dz-btn-edit { padding:4px 12px; background:transparent; color:#6B7280; border:1px solid #E5E7EB; border-radius:7px; font-size:12px; font-weight:500; cursor:pointer; }
  .dz-btn-edit:hover { background:#F3F4F6; color:#111827; }
  .dz-btn-del { padding:4px 12px; background:transparent; color:#DC2626; border:1px solid #FECACA; border-radius:7px; font-size:12px; font-weight:500; cursor:pointer; }
  .dz-btn-del:hover { background:#FEF2F2; }
  .dz-empty { text-align: center; padding: 40px 24px; color: #9CA3AF; font-size: 13px; }
  .dz-empty-icon { font-size: 36px; margin-bottom: 8px; }
  .dz-loader { text-align: center; padding: 40px; color: #9CA3AF; font-size: 13px; }
  .dz-filter-info { font-size:12px; color:#9CA3AF; margin-bottom:10px; }
  .dz-filter-info strong { color:#374151; }
  .dz-clear-filter { font-size:12px; color:#DC2626; cursor:pointer; text-decoration:underline; margin-left:8px; }
  .dz-overlay { position:fixed; inset:0; background:rgba(0,0,0,.4); z-index:9998; display:flex; align-items:center; justify-content:center; padding:16px; }
  .dz-modal { background:#fff; border-radius:12px; width:100%; max-width:400px; border:1px solid #E5E7EB; overflow:hidden; animation:dz-pop .2s ease; }
  @keyframes dz-pop { from{opacity:0;transform:scale(.96)} to{opacity:1;transform:scale(1)} }
  .dz-modal-hd { background:#F9FAFB; padding:14px 18px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #E5E7EB; }
  .dz-modal-title { font-size:14px; font-weight:600; color:#111827; }
  .dz-modal-close { background:none; border:none; color:#9CA3AF; font-size:20px; cursor:pointer; line-height:1; padding:0; }
  .dz-modal-close:hover { color:#374151; }
  .dz-modal-body { padding:18px; }
  .dz-modal-field { margin-bottom:14px; }
  .dz-modal-lbl { font-size:12px; font-weight:600; color:#6B7280; margin-bottom:6px; display:block; }
  .dz-modal-input { width:100%; padding:9px 12px; border:1px solid #E5E7EB; border-radius:8px; font-size:13px; color:#111827; outline:none; box-sizing:border-box; font-family:inherit; background:#fff; }
  .dz-modal-input:focus { border-color:#9CA3AF; }
  .dz-modal-input-readonly { background:#F9FAFB; color:#6B7280; cursor:not-allowed; }
  .dz-modal-select { width:100%; padding:9px 12px; border:1px solid #E5E7EB; border-radius:8px; font-size:13px; color:#111827; outline:none; box-sizing:border-box; font-family:inherit; background:#fff; appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%239CA3AF' viewBox='0 0 256 256'%3E%3Cpath d='M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; cursor:pointer; }
  .dz-modal-select:focus { border-color:#9CA3AF; }
  .dz-modal-err { font-size:12px; color:#DC2626; margin-bottom:10px; }
  .dz-modal-hint { font-size:11px; color:#9CA3AF; margin-top:5px; }
  .dz-toggle-row { display:flex; align-items:center; gap:10px; margin-bottom:14px; }
  .dz-toggle-lbl { font-size:13px; font-weight:500; color:#374151; }
  .dz-switch { position:relative; width:36px; height:20px; flex-shrink:0; }
  .dz-switch input { opacity:0; width:0; height:0; }
  .dz-slider { position:absolute; inset:0; background:#E5E7EB; border-radius:20px; cursor:pointer; transition:background .2s; }
  .dz-slider::before { content:''; position:absolute; width:14px; height:14px; left:3px; top:3px; background:#fff; border-radius:50%; transition:transform .2s; }
  input:checked + .dz-slider { background:#059669; }
  input:checked + .dz-slider::before { transform:translateX(16px); }
  .dz-modal-footer { display:flex; justify-content:flex-end; gap:8px; padding:0 18px 18px; }
  .dz-btn-cancel { padding:8px 16px; background:transparent; color:#6B7280; border:1px solid #E5E7EB; border-radius:8px; font-size:13px; font-weight:500; cursor:pointer; }
  .dz-btn-save { padding:8px 20px; background:#0C3B8C; color:#fff; border:none; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; }
  .dz-btn-save:hover { opacity:.88; }
  .dz-btn-save:disabled { opacity:.4; cursor:not-allowed; }
  .dz-confirm-overlay { position:fixed; inset:0; background:rgba(0,0,0,.4); z-index:9999; display:flex; align-items:center; justify-content:center; padding:16px; }
  .dz-confirm-box { background:#fff; border-radius:12px; padding:24px 20px 18px; max-width:320px; width:100%; border:1px solid #E5E7EB; text-align:center; }
  .dz-confirm-icon { font-size:36px; margin-bottom:10px; }
  .dz-confirm-title { font-size:15px; font-weight:600; color:#111827; margin-bottom:6px; }
  .dz-confirm-text { font-size:13px; color:#9CA3AF; margin-bottom:18px; }
  .dz-confirm-btns { display:flex; gap:8px; justify-content:center; }
  .dz-confirm-cancel { padding:8px 18px; background:transparent; color:#6B7280; border:1px solid #E5E7EB; border-radius:8px; font-size:13px; font-weight:500; cursor:pointer; }
  .dz-confirm-delete { padding:8px 18px; background:#FEF2F2; color:#DC2626; border:1px solid #FECACA; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; }
`;

// ─── Confirm Dialog ───────────────────────────────────────────────────────────
const ConfirmDialog = ({ stateName, onConfirm, onCancel }) => (
  <div className="dz-confirm-overlay" onClick={onCancel}>
    <div className="dz-confirm-box" onClick={e => e.stopPropagation()}>
      <div className="dz-confirm-icon">🗑️</div>
      <div className="dz-confirm-title">Delete Zone?</div>
      <div className="dz-confirm-text">"{stateName}" will be removed permanently.</div>
      <div className="dz-confirm-btns">
        <button className="dz-confirm-cancel" onClick={onCancel}>Cancel</button>
        <button className="dz-confirm-delete" onClick={onConfirm}>Yes, Delete</button>
      </div>
    </div>
  </div>
);

// ─── Main Component ───────────────────────────────────────────────────────────
const EMPTY_FORM = { state: '', charge: '', is_active: true };

const DeliveryZones = ({ showToast }) => {
  const [zones,       setZones]       = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [search,      setSearch]      = useState('');
  const [modal,       setModal]       = useState(false);
  const [editing,     setEditing]     = useState(null);
  const [form,        setForm]        = useState(EMPTY_FORM);
  const [formErr,     setFormErr]     = useState('');
  const [saving,      setSaving]      = useState(false);
  const [confirmZone, setConfirmZone] = useState(null);

  const fetchZones = useCallback(async () => {
    setLoading(true);
    try {
      const res  = await fetch(`${API_BASE_URL}/delivery-zones`);
      const data = await res.json();
      setZones(Array.isArray(data) ? data : []);
    } catch { setZones([]); }
    finally   { setLoading(false); }
  }, []);

  useEffect(() => { fetchZones(); }, [fetchZones]);

  // States already configured — used to prevent duplicates
  const configuredStates = new Set(zones.map(z => z.state).filter(Boolean));

  // For the Add modal: only show states not yet configured
  // For the Edit modal: state is locked, so this list isn't used
  const availableToAdd = INDIAN_STATES.filter(s => !configuredStates.has(s));

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormErr('');
    setModal(true);
  };

  const openEdit = (zone) => {
    setEditing(zone);
    setForm({
      state:     zone.state || '',
      charge:    String(zone.charge),
      is_active: zone.is_active,
    });
    setFormErr('');
    setModal(true);
  };

  const closeModal = () => { setModal(false); setFormErr(''); };

  const handleSave = async () => {
    if (!form.state.trim()) {
      setFormErr('Please select a state.'); return;
    }
    if (form.charge === '' || isNaN(parseFloat(form.charge)) || parseFloat(form.charge) < 0) {
      setFormErr('Enter a valid delivery charge (0 or more).'); return;
    }

    setSaving(true); setFormErr('');
    try {
      const method = editing ? 'PUT' : 'POST';
      const url    = editing
        ? `${API_BASE_URL}/delivery-zones/${editing.id}`
        : `${API_BASE_URL}/delivery-zones`;

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          state:     form.state.trim(),
          district:  form.state.trim(),  // mirrors state to satisfy backend column
          charge:    parseFloat(form.charge),
          is_active: form.is_active,
        }),
      });
      const data = await res.json();
      if (!data.success) { setFormErr(data.message || 'Failed to save.'); return; }
      closeModal();
      await fetchZones();
      showToast(
        editing ? 'Zone Updated!' : 'Zone Added!',
        `"${form.state}" saved successfully.`
      );
    } catch { setFormErr('Server error. Try again.'); }
    finally   { setSaving(false); }
  };

  const handleDelete  = (zone) => setConfirmZone(zone);
  const confirmDelete = async () => {
    const zone = confirmZone;
    setConfirmZone(null);
    try {
      const res  = await fetch(`${API_BASE_URL}/delivery-zones/${zone.id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setZones(prev => prev.filter(z => z.id !== zone.id));
        showToast('Deleted!', `"${zone.state}" removed successfully.`);
      } else {
        showToast('Delete Failed', 'Could not delete this zone.');
      }
    } catch { showToast('Server Error', 'Something went wrong. Try again.'); }
  };

  const filtered = zones.filter(z =>
    z.state?.toLowerCase().includes(search.toLowerCase())
  );

  // Stats
  const activeCount = zones.filter(z => z.is_active).length;
  const freeCount   = zones.filter(z => parseFloat(z.charge) === 0).length;
  const avgCharge   = zones.length
    ? (zones.reduce((s, z) => s + parseFloat(z.charge), 0) / zones.length).toFixed(0)
    : 0;

  return (
    <div className="dz-page">
      <style>{DZ_STYLES}</style>

      {/* ── Confirm Delete ─────────────────────────────────────────────────── */}
      {confirmZone && (
        <ConfirmDialog
          stateName={confirmZone.state}
          onConfirm={confirmDelete}
          onCancel={() => setConfirmZone(null)}
        />
      )}

      {/* ── Modal ──────────────────────────────────────────────────────────── */}
      {modal && (
        <div className="dz-overlay" onClick={closeModal}>
          <div className="dz-modal" onClick={e => e.stopPropagation()}>

            <div className="dz-modal-hd">
              <span className="dz-modal-title">
                {editing ? 'Edit Delivery Zone' : 'Add Delivery Zone'}
              </span>
              <button className="dz-modal-close" onClick={closeModal}>×</button>
            </div>

            <div className="dz-modal-body">

              {/* State field */}
              <div className="dz-modal-field">
                <label className="dz-modal-lbl">State *</label>
                {editing ? (
                  // Locked when editing — state identity should not change
                  <input
                    className="dz-modal-input dz-modal-input-readonly"
                    value={form.state}
                    readOnly
                  />
                ) : (
                  <>
                    <select
                      className="dz-modal-select"
                      value={form.state}
                      onChange={e => { setForm(p => ({ ...p, state: e.target.value })); setFormErr(''); }}
                    >
                      <option value="">— Select State —</option>
                      {availableToAdd.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                    <div className="dz-modal-hint">
                      Only states without an existing zone are listed.
                    </div>
                  </>
                )}
              </div>

              {/* Charge field */}
              <div className="dz-modal-field">
                <label className="dz-modal-lbl">Delivery Charge (₹) *</label>
                <input
                  className="dz-modal-input"
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="Enter 0 for free delivery"
                  value={form.charge}
                  autoFocus={!!editing}
                  onChange={e => { setForm(p => ({ ...p, charge: e.target.value })); setFormErr(''); }}
                />
              </div>

              {formErr && <div className="dz-modal-err">⚠ {formErr}</div>}

              {/* Active toggle */}
              <div className="dz-toggle-row">
                <span className="dz-toggle-lbl">Active</span>
                <label className="dz-switch">
                  <input
                    type="checkbox"
                    checked={form.is_active}
                    onChange={e => setForm(p => ({ ...p, is_active: e.target.checked }))}
                  />
                  <span className="dz-slider" />
                </label>
                <span style={{ fontSize: 12, fontWeight: 600, color: form.is_active ? '#2E7D32' : '#E65100' }}>
                  {form.is_active ? 'Visible in checkout' : 'Hidden from checkout'}
                </span>
              </div>

            </div>

            <div className="dz-modal-footer">
              <button className="dz-btn-cancel" onClick={closeModal}>Cancel</button>
              <button className="dz-btn-save" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Update Zone' : 'Add Zone'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ── Stats ──────────────────────────────────────────────────────────── */}
      <div className="dz-stats">
        <div className="dz-stat" style={{ borderColor: '#1A52A8' }}>
          <div className="dz-stat-val">{zones.length}</div>
          <div className="dz-stat-lbl">Total States</div>
        </div>
        <div className="dz-stat" style={{ borderColor: '#2E7D32' }}>
          <div className="dz-stat-val">{activeCount}</div>
          <div className="dz-stat-lbl">Active</div>
        </div>
        <div className="dz-stat" style={{ borderColor: '#43A047' }}>
          <div className="dz-stat-val">{freeCount}</div>
          <div className="dz-stat-lbl">Free Delivery</div>
        </div>
        <div className="dz-stat" style={{ borderColor: '#F57C00' }}>
          <div className="dz-stat-val">₹{avgCharge}</div>
          <div className="dz-stat-lbl">Avg Charge</div>
        </div>
        <div className="dz-stat" style={{ borderColor: '#6A1B9A' }}>
          <div className="dz-stat-val">{INDIAN_STATES.length - zones.length}</div>
          <div className="dz-stat-lbl">Not Configured</div>
        </div>
      </div>

      {/* ── Search + Add ───────────────────────────────────────────────────── */}
      <div className="dz-controls">
        <input
          className="dz-search"
          placeholder="Search state…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button
          className="dz-btn-add"
          onClick={openCreate}
          disabled={availableToAdd.length === 0}
          title={availableToAdd.length === 0 ? 'All states are already configured' : ''}
        >
          + Add Zone
        </button>
      </div>

      {search && (
        <div className="dz-filter-info">
          Showing <strong>{filtered.length}</strong> result{filtered.length !== 1 ? 's' : ''} for "
          <strong>{search}</strong>"
          <span className="dz-clear-filter" onClick={() => setSearch('')}>✕ Clear</span>
        </div>
      )}

      {/* ── Table ──────────────────────────────────────────────────────────── */}
      <div className="dz-card">
        {loading ? (
          <div className="dz-loader">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="dz-empty">
            <div className="dz-empty-icon">📭</div>
            <p>{search ? `No states matching "${search}".` : 'No delivery zones configured yet.'}</p>
          </div>
        ) : (
          <table className="dz-table">
            <thead>
              <tr>
                <th style={{ width: 48 }}>#</th>
                <th>State</th>
                <th>Delivery Charge</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((zone, idx) => (
                <tr key={zone.id}>
                  <td style={{ color: '#9ca3af', fontSize: 12 }}>{idx + 1}</td>
                  <td><strong>{zone.state}</strong></td>
                  <td>
                    <span className={`dz-charge ${parseFloat(zone.charge) === 0 ? 'dz-charge-free' : ''}`}>
                      {parseFloat(zone.charge) === 0
                        ? 'Free'
                        : `₹${parseFloat(zone.charge).toFixed(2)}`}
                    </span>
                  </td>
                  <td>
                    <span className={`dz-badge ${zone.is_active ? 'dz-badge-active' : 'dz-badge-inactive'}`}>
                      {zone.is_active ? '● Active' : '○ Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="dz-act-row">
                      <button className="dz-btn-edit" onClick={() => openEdit(zone)}>Edit</button>
                      <button className="dz-btn-del"  onClick={() => handleDelete(zone)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default DeliveryZones;