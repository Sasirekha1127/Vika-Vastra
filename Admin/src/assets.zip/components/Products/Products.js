// admin/Products.jsx  —  full replacement
import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import DataTable from '../DataTable/DataTable';

const API = process.env.REACT_APP_API_URL;

// ── Design tokens ─────────────────────────────────────────────────────────────
const KM = {
  orange: '#F15A24', orangeLight: '#FEF0EB',
  blue: '#1A3A6B',   blueLight: '#EEF2F9',
  green: '#39B54A',
  teal: '#00B4D8',
  border: '#E5E7EB',
  text: '#1A1A2E',   muted: '#6B7280', bg: '#F9FAFB',
  red: '#EF4444',    redLight: '#FEF2F2',
};

function stockColor(qty) {
  if (qty > 200) return KM.green;
  if (qty > 50)  return '#F59E0B';
  return '#EF4444';
}

// ── Shared style objects ──────────────────────────────────────────────────────
const formCard   = { background: '#fff', border: `1px solid ${KM.border}`, borderRadius: 12, overflow: 'hidden', marginBottom: 20 };
const formHeader = { background: KM.blue, padding: '16px 24px', display: 'flex', alignItems: 'center', gap: 10 };
const headerIcon = { width: 32, height: 32, background: 'rgba(255,255,255,0.15)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 15, fontWeight: 600 };
const fieldStyle = { display: 'flex', flexDirection: 'column', gap: 5 };
const labelStyle = { fontSize: 11, fontWeight: 500, color: KM.muted, textTransform: 'uppercase', letterSpacing: '0.05em' };
const inputStyle = { padding: '9px 12px', border: `1px solid ${KM.border}`, borderRadius: 8, fontSize: 13, color: KM.text, background: '#fff', fontFamily: 'inherit', outline: 'none', width: '100%', boxSizing: 'border-box' };
const submitBtn  = { gridColumn: 'span 2', padding: 11, background: KM.orange, color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: 'pointer', fontFamily: 'inherit', marginTop: 4 };

// ── Initial form state ────────────────────────────────────────────────────────
const EMPTY_FORM = {
  productName: '', categoryId: '', subCategoryId: '', brandId: '',
  shortDescription: '', longDescription: '',
  mrp: '', salesPrice: '', stock: '0',
  isNewArrival: false, isBestSeller: false,
};

// ── Helper: resolve image src ─────────────────────────────────────────────────
const resolveImageSrc = (image) => {
  if (!image) return null;
  if (image.startsWith('data:') || image.startsWith('http')) return image;
  const base = (API || '').replace(/\/$/, '');
  return `${base}${image.startsWith('/') ? image : `/${image}`}`;
};

// ── GalleryUploader sub-component ─────────────────────────────────────────────
// Shows existing gallery images (kept / to-be-deleted) + a drag-drop zone for
// new uploads. Calls back with { newFiles, keepIds } on every change.
function GalleryUploader({ existingImages = [], onChange }) {
  // existingImages: [{ id, url }]  — already saved in DB
  const [kept,     setKept]     = useState(existingImages);   // existing images to keep
  const [newFiles, setNewFiles] = useState([]);               // new File objects
  const [previews, setPreviews] = useState([]);               // object-URLs for newFiles
  const inputRef = useRef();

  // When the parent opens edit mode it passes fresh existingImages —
  // reset local state to match.
  useEffect(() => {
    setKept(existingImages);
    setNewFiles([]);
    setPreviews([]);
  }, [JSON.stringify(existingImages)]); // eslint-disable-line

  // Notify parent whenever kept or newFiles changes
  useEffect(() => {
    onChange({ newFiles, keepIds: kept.map(i => i.id) });
  }, [kept, newFiles]); // eslint-disable-line

  const handleFilePick = (files) => {
    const picked = Array.from(files);
    const urls   = picked.map(f => URL.createObjectURL(f));
    setNewFiles(prev => [...prev, ...picked]);
    setPreviews(prev => [...prev, ...urls]);
  };

  const removeExisting = (id) => setKept(prev => prev.filter(i => i.id !== id));
  const removeNew      = (idx) => {
    URL.revokeObjectURL(previews[idx]);
    setNewFiles(prev => prev.filter((_, i) => i !== idx));
    setPreviews(prev => prev.filter((_, i) => i !== idx));
  };

  const onDrop = (e) => {
    e.preventDefault();
    handleFilePick(e.dataTransfer.files);
  };

  const totalCount = kept.length + newFiles.length;

  return (
    <div>
      {/* Thumbnail grid */}
      {totalCount > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
          {/* Existing kept images */}
          {kept.map(img => (
            <div key={img.id} style={{ position: 'relative', width: 64, height: 64 }}>
              <img
                src={resolveImageSrc(img.url)}
                alt=""
                style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 8, border: `1.5px solid ${KM.border}` }}
                onError={e => { e.target.style.display = 'none'; }}
              />
              <button
                type="button"
                onClick={() => removeExisting(img.id)}
                style={{
                  position: 'absolute', top: -6, right: -6,
                  width: 18, height: 18, borderRadius: '50%',
                  background: KM.red, color: '#fff', border: 'none',
                  fontSize: 10, lineHeight: '18px', textAlign: 'center',
                  cursor: 'pointer', fontWeight: 700, padding: 0,
                }}
              >✕</button>
            </div>
          ))}
          {/* New (unsaved) images */}
          {previews.map((src, idx) => (
            <div key={`new-${idx}`} style={{ position: 'relative', width: 64, height: 64 }}>
              <img
                src={src}
                alt=""
                style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 8, border: `1.5px dashed ${KM.teal}` }}
              />
              <button
                type="button"
                onClick={() => removeNew(idx)}
                style={{
                  position: 'absolute', top: -6, right: -6,
                  width: 18, height: 18, borderRadius: '50%',
                  background: '#888', color: '#fff', border: 'none',
                  fontSize: 10, lineHeight: '18px', textAlign: 'center',
                  cursor: 'pointer', fontWeight: 700, padding: 0,
                }}
              >✕</button>
              {/* "new" badge */}
              <span style={{
                position: 'absolute', bottom: 2, left: 2,
                fontSize: 8, background: KM.teal, color: '#fff',
                borderRadius: 3, padding: '1px 4px', fontWeight: 700,
              }}>NEW</span>
            </div>
          ))}
        </div>
      )}

      {/* Drop zone */}
      <div
        onDrop={onDrop}
        onDragOver={e => e.preventDefault()}
        onClick={() => inputRef.current?.click()}
        style={{
          border: `1.5px dashed ${KM.teal}`, borderRadius: 8, padding: 16,
          textAlign: 'center', background: '#F0FAFE', cursor: 'pointer',
          transition: 'background .15s',
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          style={{ display: 'none' }}
          onChange={e => handleFilePick(e.target.files)}
        />
        <span style={{ color: KM.muted, fontSize: 13 }}>
          {totalCount === 0
            ? '📷  Click or drag images here to add gallery photos'
            : `📷  Add more images  (${totalCount} so far)`}
        </span>
      </div>
      {totalCount > 0 && (
        <p style={{ fontSize: 11, color: KM.muted, marginTop: 4 }}>
          {kept.length} existing · {newFiles.length} new · click ✕ to remove
        </p>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
export default function Products({ showToast }) {
  const location = useLocation();

  const [rows,          setRows]          = useState([]);
  const [categories,    setCategories]    = useState([]);
  const [subCategories, setSubCategories] = useState([]);
  const [brands,        setBrands]        = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [showForm,      setShowForm]      = useState(false);
  const [imageFile,     setImageFile]     = useState(null);
  const [imagePreview,  setImagePreview]  = useState(null);
  const [editingId,     setEditingId]     = useState(null);
  const [formData,      setFormData]      = useState(EMPTY_FORM);

  // Gallery state managed by GalleryUploader; we hold the callback result here
  const [galleryState,     setGalleryState]     = useState({ newFiles: [], keepIds: [] });
  // Existing gallery images for the product being edited
  const [existingGallery,  setExistingGallery]  = useState([]);

  // ── Data fetching ─────────────────────────────────────────────────────────
  useEffect(() => {
    fetchCategories();
    fetchSubCategories();
    fetchBrands();
    fetchProducts();
  }, [location.search]); // eslint-disable-line react-hooks/exhaustive-deps

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const res  = await fetch(`${API}/products`);
      const data = await res.json();
      setRows(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories    = async () => { try { const r = await fetch(`${API}/categories`);   const d = await r.json(); setCategories(Array.isArray(d) ? d : []); } catch { } };
  const fetchSubCategories = async () => { try { const r = await fetch(`${API}/subcategories`); const d = await r.json(); setSubCategories(Array.isArray(d) ? d : []); } catch { } };
  const fetchBrands        = async () => { try { const r = await fetch(`${API}/brands`);        const d = await r.json(); setBrands(Array.isArray(d) ? d : []); } catch { } };

  const filteredSubCategories = subCategories.filter(
    (sc) => String(sc.categoryId) === String(formData.categoryId)
  );

  // ── Reset form ────────────────────────────────────────────────────────────
  const resetForm = () => {
    setEditingId(null);
    setShowForm(false);
    setFormData(EMPTY_FORM);
    setImageFile(null);
    setImagePreview(null);
    setExistingGallery([]);
    setGalleryState({ newFiles: [], keepIds: [] });
  };

  // ── Open add ──────────────────────────────────────────────────────────────
  const handleAddClick = () => {
    if (showForm) { resetForm(); return; }
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ── Open edit ─────────────────────────────────────────────────────────────
  const handleEditClick = (product) => {
    setEditingId(product.id);
    setFormData({
      productName:      product.productName,
      categoryId:       product.categoryId    || '',
      subCategoryId:    product.subCategoryId || '',
      brandId:          product.brandId       || '',
      shortDescription: product.shortDescription || '',
      longDescription:  product.longDescription  || '',
      mrp:              product.mrp?.toString()       || '',
      salesPrice:       product.salesPrice?.toString() || '',
      stock:            product.stock?.toString()      || '0',
      isNewArrival:     !!product.isNewArrival,
      isBestSeller:     !!product.isBestSeller,
    });
    setImagePreview(product.image || null);
    setImageFile(null);

    // Pre-populate gallery with existing Images association
    const imgs = (product.Images || []).map(img => ({
      id:  img.id,
      url: img.url,
    }));
    setExistingGallery(imgs);
    setGalleryState({ newFiles: [], keepIds: imgs.map(i => i.id) });

    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ── Submit ────────────────────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();

    const priceValue = parseFloat(formData.salesPrice || formData.mrp || 0);
    const mrpValue   = parseFloat(formData.mrp || 0);
    const stockValue = parseInt(formData.stock || 0, 10);

    if (!formData.productName.trim())  { showToast('Validation Error', 'Product name is required.');                     return; }
    if (!formData.categoryId)          { showToast('Validation Error', 'Please select a category.');                     return; }
    if (mrpValue <= 0 || priceValue <= 0) { showToast('Validation Error', 'MRP and Sale Price must be greater than zero.'); return; }
    if (stockValue < 0)                { showToast('Validation Error', 'Stock cannot be negative.');                     return; }

    const data = new FormData();
    Object.keys(formData).forEach((key) => data.append(key, formData[key]));

    // Main image
    if (imageFile) data.append('image', imageFile);

    // Gallery: new files
    galleryState.newFiles.forEach(f => data.append('gallery', f));

    // Gallery: IDs to keep (so backend knows which to delete)
    if (editingId) {
      data.append('keepImageIds', JSON.stringify(galleryState.keepIds));
    }

    const method = editingId ? 'PUT' : 'POST';
    const url    = editingId
      ? `${API}/products/update/${editingId}`
      : `${API}/products/add`;

    try {
      const res = await fetch(url, { method, body: data });
      if (res.ok) {
        showToast(editingId ? 'Updated!' : 'Added!', editingId ? 'Product updated successfully.' : 'New product added.');
        resetForm();
        fetchProducts();
      } else {
        const err = await res.json();
        showToast('Failed', err.error || 'Operation could not be completed.');
      }
    } catch {
      showToast('Server Error', 'Something went wrong. Try again.');
    }
  };

  // ── Delete ────────────────────────────────────────────────────────────────
  const handleDelete = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try {
      const res = await fetch(`${API}/products/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setRows(prev => prev.filter(r => r.id !== id));
        showToast('Deleted!', 'Product removed successfully.');
      }
    } catch {
      showToast('Error', 'Could not complete the delete action.');
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div>
      {/* Section header */}
      <div className="section-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="section-title">Products Management</div>
        </div>
        <button className="action-btn btn-edit" onClick={handleAddClick}>
          {showForm ? 'Close' : '+ Add Product'}
        </button>
      </div>

      {/* Add / Edit form */}
      {showForm && (
        <div style={formCard}>
          <div style={formHeader}>
            <div style={headerIcon}>P</div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 500, color: '#fff' }}>
                {editingId ? 'Edit Product' : 'Add New Product'}
              </div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', marginTop: 1 }}>
                Manage product details, inventory, and gallery images
              </div>
            </div>
          </div>

          <div style={{ padding: '20px 24px 28px' }}>
            <form onSubmit={handleSubmit} style={{ display: 'grid', gap: 14, gridTemplateColumns: '1fr 1fr' }}>

              {/* Product Name */}
              <div style={{ ...fieldStyle, gridColumn: 'span 2' }}>
                <label style={labelStyle}>Product Name *</label>
                <input style={inputStyle} type="text" required value={formData.productName}
                  onChange={e => setFormData({ ...formData, productName: e.target.value })} />
              </div>

              {/* Category */}
              <div style={fieldStyle}>
                <label style={labelStyle}>Category *</label>
                <select style={inputStyle} required value={formData.categoryId}
                  onChange={e => setFormData({ ...formData, categoryId: e.target.value, subCategoryId: '' })}>
                  <option value="">Select Category</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              {/* Sub-Category */}
              <div style={fieldStyle}>
                <label style={labelStyle}>Sub-Category</label>
                <select style={inputStyle} value={formData.subCategoryId}
                  onChange={e => setFormData({ ...formData, subCategoryId: e.target.value })}
                  disabled={!formData.categoryId}>
                  <option value="">Select Sub-Category</option>
                  {filteredSubCategories.map(sc => <option key={sc.id} value={sc.id}>{sc.name}</option>)}
                </select>
              </div>

              {/* Brand */}
              <div style={{ ...fieldStyle, gridColumn: 'span 2' }}>
                <label style={labelStyle}>Brand</label>
                <select style={inputStyle} value={formData.brandId}
                  onChange={e => setFormData({ ...formData, brandId: e.target.value })}>
                  <option value="">Select Brand (Optional)</option>
                  {brands.map(b => <option key={b.id} value={b.id}>{b.brandName}</option>)}
                </select>
              </div>

              {/* Short Description */}
              <div style={{ ...fieldStyle, gridColumn: 'span 2' }}>
                <label style={labelStyle}>Short Description</label>
                <input style={inputStyle} type="text" maxLength={300}
                  placeholder="Brief product summary (max 300 characters)"
                  value={formData.shortDescription}
                  onChange={e => setFormData({ ...formData, shortDescription: e.target.value })} />
                <span style={{ fontSize: 11, color: KM.muted, textAlign: 'right' }}>{formData.shortDescription.length}/300</span>
              </div>

              {/* Long Description */}
              <div style={{ ...fieldStyle, gridColumn: 'span 2' }}>
                <label style={labelStyle}>Long Description</label>
                <textarea style={{ ...inputStyle, minHeight: 110, resize: 'vertical', lineHeight: 1.6 }}
                  placeholder="Detailed product description, features, usage instructions…"
                  value={formData.longDescription}
                  onChange={e => setFormData({ ...formData, longDescription: e.target.value })} />
              </div>

              {/* Pricing */}
              <div style={fieldStyle}>
                <label style={labelStyle}>MRP *</label>
                <input style={inputStyle} type="number" min="0" step="0.01" required
                  value={formData.mrp} onChange={e => setFormData({ ...formData, mrp: e.target.value })} />
              </div>
              <div style={fieldStyle}>
                <label style={labelStyle}>Sale Price *</label>
                <input style={inputStyle} type="number" min="0" step="0.01" required
                  value={formData.salesPrice} onChange={e => setFormData({ ...formData, salesPrice: e.target.value })} />
              </div>
              <div style={fieldStyle}>
                <label style={labelStyle}>Stock *</label>
                <input style={inputStyle} type="number" min="0" step="1" required
                  value={formData.stock} onChange={e => setFormData({ ...formData, stock: e.target.value })} />
              </div>

              {/* Flags */}
              <div style={{ gridColumn: 'span 2', display: 'flex', gap: 20, padding: '12px 14px', background: KM.orangeLight, borderRadius: 8 }}>
                {[{ key: 'isNewArrival', label: 'New Arrival' }, { key: 'isBestSeller', label: 'Best Seller' }].map(item => (
                  <label key={item.key} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer' }}>
                    <input type="checkbox" checked={formData[item.key]}
                      onChange={e => setFormData({ ...formData, [item.key]: e.target.checked })} />
                    {item.label}
                  </label>
                ))}
              </div>

              {/* ── Main Product Image ──────────────────────────────────────── */}
              <div style={{ ...fieldStyle, gridColumn: 'span 2' }}>
                <label style={labelStyle}>Main Product Image</label>
                {(imagePreview && !imageFile) && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                    <img src={resolveImageSrc(imagePreview)} alt="Current product" width={56} height={56}
                      onError={e => { e.target.style.display = 'none'; }}
                      style={{ borderRadius: 8, objectFit: 'cover', border: `1.5px solid ${KM.border}` }} />
                    <div>
                      <div style={{ fontSize: 11, color: KM.muted }}>Current main image</div>
                      <button type="button" onClick={() => setImagePreview(null)}
                        style={{ marginTop: 3, fontSize: 11, color: KM.red, background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'inherit' }}>
                        ✕ Remove
                      </button>
                    </div>
                  </div>
                )}
                <div style={{ border: `1.5px dashed ${KM.teal}`, borderRadius: 8, padding: 18, textAlign: 'center', background: '#F0FAFE', position: 'relative', cursor: 'pointer' }}>
                  <input type="file" accept="image/*"
                    onChange={e => { const f = e.target.files[0]; if (f) { setImageFile(f); setImagePreview(null); } }}
                    style={{ opacity: 0, position: 'absolute', width: '100%', height: '100%', top: 0, left: 0, cursor: 'pointer' }} />
                  {imageFile
                    ? <span style={{ color: KM.green, fontWeight: 600 }}>✓ {imageFile.name}</span>
                    : <span style={{ color: KM.muted }}>{imagePreview ? 'Click to replace main image' : 'Click to upload main product image'}</span>}
                </div>
              </div>

              {/* ── Gallery Images ──────────────────────────────────────────── */}
              <div style={{ ...fieldStyle, gridColumn: 'span 2' }}>
                <label style={labelStyle}>
                  Gallery Images
                  <span style={{ fontSize: 10, fontWeight: 400, marginLeft: 6, color: KM.teal }}>(shown in image selector on product page)</span>
                </label>
                <GalleryUploader
                  existingImages={existingGallery}
                  onChange={setGalleryState}
                />
              </div>

              {/* Submit */}
              <button type="submit" style={submitBtn}>
                {editingId ? 'Update Product' : 'Save Product'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Products table */}
      {loading ? (
        <p style={{ padding: 20, color: KM.muted }}>Loading products…</p>
      ) : (
        <DataTable
          columns={['ID', 'Image', 'Product', 'Brand', 'Price', 'Stock', 'Category / Sub', 'Actions']}
          initialRows={rows}
          renderRow={(row) => {
            const priceValue     = Number(row.salesPrice || row.mrp || 0);
            const stockValue     = Number(row.stock || 0);
            const hasPricingIssue = priceValue <= 0 || Number(row.mrp || 0) <= 0;
            const galleryCount   = row.Images?.length || 0;

            return (
              <tr key={row.id}>
                <td style={{ color: KM.muted }}>#{row.id}</td>

                <td>
                  {row.image ? (
                    <img src={resolveImageSrc(row.image)} alt="" width="40" height="40"
                      onError={e => { e.target.style.display = 'none'; }}
                      style={{ borderRadius: 6, objectFit: 'cover' }} />
                  ) : (
                    <div style={{ width: 40, height: 40, borderRadius: 6, background: KM.bg, border: `1px solid ${KM.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, color: KM.muted }}>📦</div>
                  )}
                </td>

                <td>
                  <div style={{ fontWeight: 600 }}>{row.productName}</div>
                  {row.shortDescription && (
                    <div style={{ fontSize: 11, color: KM.muted, marginTop: 2, maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{row.shortDescription}</div>
                  )}
                  <div style={{ display: 'flex', gap: 4, marginTop: 4, flexWrap: 'wrap' }}>
                    {row.isNewArrival  && <span style={{ fontSize: 10, background: '#DCFCE7', color: '#16A34A', borderRadius: 4, padding: '1px 6px', fontWeight: 600 }}>New</span>}
                    {row.isBestSeller  && <span style={{ fontSize: 10, background: '#FEF9C3', color: '#CA8A04', borderRadius: 4, padding: '1px 6px', fontWeight: 600 }}>Best Seller</span>}
                    {hasPricingIssue   && <span style={{ fontSize: 10, background: KM.redLight, color: KM.red, borderRadius: 4, padding: '1px 6px', fontWeight: 600 }}>⚠ Missing Price</span>}
                    {galleryCount > 0  && <span style={{ fontSize: 10, background: '#E0F2FE', color: '#0369A1', borderRadius: 4, padding: '1px 6px', fontWeight: 600 }}>🖼 {galleryCount} photo{galleryCount !== 1 ? 's' : ''}</span>}
                  </div>
                </td>

                <td style={{ fontSize: 12, color: KM.teal, fontWeight: 500 }}>{row.Brand?.brandName || '—'}</td>

                <td style={{ fontWeight: 700, color: priceValue === 0 ? KM.red : KM.text }}>
                  {priceValue === 0 ? '⚠ ₹0.00' : `₹${priceValue.toFixed(2)}`}
                </td>

                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: stockValue === 0 ? '#dc2626' : stockColor(stockValue) }} />
                    <span style={{ fontWeight: 700, color: stockValue === 0 ? '#dc2626' : KM.text }}>{stockValue}</span>
                  </div>
                </td>

                <td>
                  <div style={{ fontSize: 12, fontWeight: 500 }}>{row.Category?.name || 'N/A'}</div>
                  <div style={{ fontSize: 11, color: KM.teal }}>{row.SubCategory?.name || '—'}</div>
                </td>

                <td>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="action-btn btn-edit" onClick={() => handleEditClick(row)}>Edit</button>
                    <button className="action-btn btn-del"  onClick={() => handleDelete(row.id)}>Delete</button>
                  </div>
                </td>
              </tr>
            );
          }}
        />
      )}
    </div>
  );
}